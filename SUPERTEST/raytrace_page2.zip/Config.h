#pragma once
#ifndef __CONFIG_H
#define __CONFIG_H

#include "Raytrace.h"
#include "SimpleString.h"

class Config {
private:
    void * m_pVariables;
    void * m_pSections;
    const SimpleString m_sFileName;
    SimpleString m_sCurrentSection;
    bool m_bLoaded;
public:
    // Quand la variable n'existe pas, vous recup�rez la valeur "default" 
    bool GetByNameAsBoolean(const SimpleString  & sName, bool bDefault) const;
    double GetByNameAsFloat(const SimpleString & sName, double fDefault) const;
    const SimpleString &GetByNameAsString(const SimpleString  &sName, const SimpleString  & sDefault) const;
    long GetByNameAsInteger(const SimpleString  &sName, long lDefault) const;
    vecteur GetByNameAsVector(const SimpleString &sName, const vecteur& vDefault) const;
    point GetByNameAsPoint(const SimpleString &sName, const point& ptDefault) const;
    
    // SetSection renvoie -1 quand la section n'est pas trouv�e. 
    int SetSection(const SimpleString &sName);
    ~Config();
    Config(const SimpleString &sFileName);
};

#endif //__CONFIG_H
