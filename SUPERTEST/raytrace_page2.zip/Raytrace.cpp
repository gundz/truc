#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <limits>
#include <algorithm>
using namespace std;

#include "Raytrace.h"
#include "String.h"
#include "Config.h"

const vecteur NullVector = { 0.0f,0.0f,0.0f };
const point Origin = { 0.0f,0.0f,0.0f };

void GetMaterial(const Config &sceneFile, material &currentMat)
{
    currentMat.diffuse.blue =  float(sceneFile.GetByNameAsFloat("Diffuse.Blue", 0.0f)); 
    currentMat.diffuse.red  =  float(sceneFile.GetByNameAsFloat("Diffuse.Red", 0.0f)); 
    currentMat.diffuse.green = float(sceneFile.GetByNameAsFloat("Diffuse.Green", 1.0f)); 

    currentMat.reflection = float(sceneFile.GetByNameAsFloat("Reflection", 0.0f));

    currentMat.specular.blue = float(sceneFile.GetByNameAsFloat("Specular.Blue", 0.0f));
    currentMat.specular.red = float(sceneFile.GetByNameAsFloat("Specular.Red", 0.0f));
    currentMat.specular.green = float(sceneFile.GetByNameAsFloat("Specular.Green", 0.0f));

    currentMat.power = float(sceneFile.GetByNameAsFloat("Power", 0.0f));
}

void GetSphere(const Config &sceneFile, sphere &currentSph)
{
    currentSph.pos = sceneFile.GetByNameAsPoint("Center", Origin); 

    currentSph.size =  float(sceneFile.GetByNameAsFloat("Size", 0.0f)); 

    currentSph.materialId = sceneFile.GetByNameAsInteger("Material.Id", 0); 
}

void GetLight(const Config &sceneFile, light &currentLight)
{
    currentLight.pos = sceneFile.GetByNameAsPoint("Position", Origin); 

    currentLight.intensity.blue =  float(sceneFile.GetByNameAsFloat("Intensity.Blue", 1.0f)); 
    currentLight.intensity.red  =  float(sceneFile.GetByNameAsFloat("Intensity.Red", 1.0f)); 
    currentLight.intensity.green = float(sceneFile.GetByNameAsFloat("Intensity.Green", 1.0f)); 
}

bool init(char* inputName, scene &myScene)
{
	int nbMats, nbSpheres, nbLights;
	int i;
	Config sceneFile(inputName);
    if (sceneFile.SetSection("Scene") == -1)
    {
        cout << "Fichier scene mal form�" << endl;
		return false;
    }
    myScene.sizex = sceneFile.GetByNameAsInteger("ImageWidth", 640);
    myScene.sizey = sceneFile.GetByNameAsInteger("ImageHeight", 480);
    nbMats = sceneFile.GetByNameAsInteger("NumberOfMaterials", 0);
    nbSpheres = sceneFile.GetByNameAsInteger("NumberOfSpheres", 0);
    nbLights = sceneFile.GetByNameAsInteger("NumberOfLights", 0);

	myScene.materialArray.resize(nbMats);
	myScene.sphereArray.resize(nbSpheres);
	myScene.lightArray.resize(nbLights);

	for (i=0; i<nbMats; ++i)
    {   
        material &currentMat = myScene.materialArray[i];
        SimpleString sectionName("Material");
        sectionName.append((unsigned long) i);
        if (sceneFile.SetSection( sectionName ) == -1)
        {
            cout << "Fichier scene mal form�" << endl;
		    return false;
        }
        GetMaterial(sceneFile, currentMat);
    }
	for (i=0; i<nbSpheres; ++i)
    {   
        sphere &currentSphere = myScene.sphereArray[i];
        SimpleString sectionName("Sphere");
        sectionName.append((unsigned long) i);
        if (sceneFile.SetSection( sectionName ) == -1)
        {
            cout << "Fichier scene mal form�" << endl;
		    return false;
        }
        GetSphere(sceneFile, currentSphere);
        if (currentSphere.materialId >= nbMats)
        {
            cout << "Fichier scene mal form�" << endl;
		    return false;
        }

    }
	for (i=0; i<nbLights; ++i)
    {   
        light &currentLight = myScene.lightArray[i];
        SimpleString sectionName("Light");
        sectionName.append((unsigned long) i);
        if (sceneFile.SetSection( sectionName ) == -1)
        {
            cout << "Fichier scene mal form�" << endl;
		    return false;
        }
        GetLight(sceneFile, currentLight);
        
    }
	return true;
}

bool hitSphere(const ray &r, const sphere& s, float &t)
{
	vecteur dist = s.pos - r.start;
	float B = (r.dir.x * dist.x + r.dir.y * dist.y + r.dir.z * dist.z);
	float D = B*B - dist*dist + s.size * s.size;
	if (D < 0.0f) return false;
	float t0 = B - sqrtf(D);
	float t1 = B + sqrtf(D);
	bool retvalue = false;
	if ((t0 > 0.1f ) && (t0 < t))
	{
		t = t0;
		retvalue = true;
	}
	if ((t1 > 0.1f ) && (t1 < t))
	{
		t = t1;
		retvalue = true;
	}
	return retvalue;
}

color addRay(ray viewRay, scene &myScene)
{
	color output = {0.0f, 0.0f, 0.0f}; 
	float coef = 1.0f;
	int level = 0;
	do 
	{
        point ptHitPoint;
		int currentSphere=-1;
        {
		    float t = 20000.0f;
		    for (unsigned int i = 0; i < myScene.sphereArray.size() ; ++i)
		    {
			    if (hitSphere(viewRay, myScene.sphereArray[i], t))
			    {
				    currentSphere = i;
			    }
		    }
		    if (currentSphere == -1)
			    break;
    		
		    ptHitPoint  = viewRay.start + t * viewRay.dir;
        }
		vecteur vNormal = ptHitPoint - myScene.sphereArray[currentSphere].pos;
		float temp = vNormal * vNormal;
		if (temp == 0.0f)
			break;
		temp = 1.0f / sqrtf(temp);
		vNormal = temp * vNormal;
		material currentMat = myScene.materialArray[myScene.sphereArray[currentSphere].materialId];

		ray lightRay;
		lightRay.start = ptHitPoint;

		for (unsigned int j = 0; j < myScene.lightArray.size() ; ++j)
		{
			light currentLight = myScene.lightArray[j];

		    lightRay.dir = currentLight.pos - ptHitPoint;
            float fLightProjection = lightRay.dir * vNormal;

			if ( fLightProjection <= 0.0f )
				continue;

			float lightDist = lightRay.dir * lightRay.dir;
            {
                float temp = lightDist;
			    if ( temp == 0.0f )
				    continue;
                temp = invsqrtf(temp);
			    lightRay.dir = temp * lightRay.dir;
                fLightProjection = temp * fLightProjection;
            }

			bool inShadow = false;
            {
                float t = lightDist;
			    for (unsigned int i = 0; i < myScene.sphereArray.size() ; ++i)
			    {
				    if (hitSphere(lightRay, myScene.sphereArray[i], t))
				    {
					    inShadow = true;
					    break;
				    }
			    }
            }


			if (!inShadow)
			{
				float lambert = (lightRay.dir * vNormal) * coef;
				output.red += lambert * currentLight.intensity.red * currentMat.diffuse.red;
				output.green += lambert * currentLight.intensity.green * currentMat.diffuse.green;
				output.blue += lambert * currentLight.intensity.blue * currentMat.diffuse.blue;

				// Blinn 
                // La direction de Blinn est exactement � mi chemin entre le rayon
                // lumineux et le rayon de vue. 
                // On calcule le vecteur de Blinn et on le rend unitaire
                // puis on calcule le co�fficient de blinn
                // qui est la contribution sp�culaire de la lumi�re courante.

                float fViewProjection = viewRay.dir * vNormal;
				vecteur blinnDir = lightRay.dir - viewRay.dir;
				float temp = blinnDir * blinnDir;
				if (temp != 0.0f )
				{
					float blinn = invsqrtf(temp) * max(fLightProjection - fViewProjection , 0.0f);
                    blinn = coef * powf(blinn, currentMat.power);
					output += blinn *currentMat.specular  * currentLight.intensity;
				}
			}
		}
		coef *= currentMat.reflection;
		float reflet = 2.0f * (viewRay.dir * vNormal);
        viewRay.start = ptHitPoint;
		viewRay.dir = viewRay.dir - reflet * vNormal;
		level++;
	} while ((coef > 0.0f) && (level < 10));  
    return output;
}

bool draw(char* outputName, scene &myScene)
{
	int x, y;
	ofstream imageFile(outputName,ios_base::binary);
	if (!imageFile)
		return false;
	// specific TGA handling code
	imageFile.put(0).put(0);
	imageFile.put(2);                  /* uncompressed RGB */

	imageFile.put(0).put(0);
	imageFile.put(0).put(0);
	imageFile.put(0);

	imageFile.put(0).put(0);           /* X origin */
	imageFile.put(0).put(0);           /* y origin */

	imageFile.put((myScene.sizex & 0x00FF)).put((myScene.sizex & 0xFF00) / 256);
	imageFile.put((myScene.sizey & 0x00FF)).put((myScene.sizey & 0xFF00) / 256);
	imageFile.put(24);                 /* 24 bit bitmap */
	imageFile.put(0);
	
	for (y = 0; y < myScene.sizey; ++y)
	{
		for (x = 0 ; x < myScene.sizex; ++x)
		{
			color output = {0.0f, 0.0f, 0.0f};
			for (float fragmentx = float(x) ; fragmentx < x + 1.0f; fragmentx += 0.5f )
			for (float fragmenty = float(y) ; fragmenty < y + 1.0f; fragmenty += 0.5f )
			{
				float sampleRatio=0.25f;
				ray viewRay = { {fragmentx, fragmenty, -10000.0f},{ 0.0f, 0.0f, 1.0f}};
                color temp = addRay (viewRay, myScene);
                // exposition photo
                float exposure = -1.00f; // valeur prise au pif pour l'instant.
	            temp.blue = (1.0f - expf(temp.blue * exposure));
	            temp.red =  (1.0f - expf(temp.red * exposure));
	            temp.green = (1.0f - expf(temp.green * exposure));

	            output += sampleRatio * temp;
			}
						
			// gamma correction
			float invgamma = 0.45f; // c'est la valeur fix�e par le standard sRGB
			output.blue = powf(output.blue, invgamma);
			output.red = powf(output.red, invgamma);
			output.green = powf(output.green, invgamma);

            if (y < 10)
            {
                if ((x / 10) & 1)
                {
                    imageFile.put((unsigned char)186).put((unsigned char)186).put((unsigned char)186);
                }
                else if ( y & 1)
                {
                    imageFile.put((unsigned char)255).put((unsigned char)255).put((unsigned char)255);
                }
                else
                {
                    imageFile.put((unsigned char)0).put((unsigned char)0).put((unsigned char)0);
                }
            }
            else
            {
                imageFile.put((unsigned char)min(output.blue*255.0f,255.0f)).put((unsigned char)min(output.green*255.0f, 255.0f)).put((unsigned char)min(output.red*255.0f, 255.0f));
            }
        }
	}
	return true;
}

int main(int argc, char* argv[])
{
	if (argc < 3)
    {
        cout << "Usage : Raytrace.exe Scene.txt Output.tga" << endl;
		return -1;
    }
	scene myScene;
	if (!init(argv[1], myScene))
    {
        cout << "Echec � l'ouverture du fichier sc�ne." << endl;
		return -1;
    }
	if (!draw(argv[2], myScene))
    {
        cout << "Echec � la cr�ation du fichier image." << endl;
		return -1;
    }
	return 0;
}
