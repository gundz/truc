#pragma once
#ifndef __RAYTRACE_H
#define __RAYTRACE_H
#include <vector>

struct point {
	float x, y, z;
};

struct vecteur {
	float x, y, z;
};

inline point operator + (const point&p, const vecteur &v){
	point p2={p.x + v.x, p.y + v.y, p.z + v.z };
	return p2;
}

inline point operator - (const point&p, const vecteur &v){
	point p2={p.x - v.x, p.y - v.y, p.z - v.z };
	return p2;
}

inline vecteur operator - (const point&p1, const point &p2){
	vecteur v={p1.x - p2.x, p1.y - p2.y, p1.z - p2.z };
	return v;
}

inline vecteur operator * (float c, const vecteur &v)
{
	vecteur v2={v.x *c, v.y * c, v.z * c };
	return v2;
}

inline vecteur operator - (const vecteur&v1, const vecteur &v2){
	vecteur v={v1.x - v2.x, v1.y - v2.y, v1.z - v2.z };
	return v;
}

inline float operator * (const vecteur&v1, const vecteur &v2 ) {
	return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}

struct color {
	float red, green, blue;
};

inline color operator * (const color&c1, const color &c2 ) {
	color c = {c1.red * c2.red, c1.green * c2.green, c1.blue * c2.blue};
	return c;
}

inline color operator + (const color&c1, const color &c2 ) {
	color c = {c1.red + c2.red, c1.green + c2.green, c1.blue + c2.blue};
	return c;
}

inline color & operator += (color&c1, const color &c2 ) {
	c1.red +=  c2.red;
    c1.green += c2.green;
    c1.blue += c2.blue;
	return c1;
}

inline color operator * (float coef, const color &c ) {
	color c2 = {c.red * coef, c.green * coef, c.blue * coef};
	return c2;
}

struct material {
    color diffuse;
    float reflection;
    color specular;
    float power;
};

struct sphere {
	point pos;
	float size;
	int materialId;
};

struct light {
	point pos;
	color intensity;
};

struct ray {
	point start;
	vecteur dir;
};

struct scene {
    std::vector<material> materialArray;
	std::vector<sphere>   sphereArray;
	std::vector<light>    lightArray;
	int sizex, sizey;
};

#define invsqrtf(x) (1.0f / sqrtf(x))

#endif // __RAYTRACE_H
