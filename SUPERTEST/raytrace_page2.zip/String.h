#pragma once
#ifndef __STRING_H
#define __STRING_H

#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cstdio>
#include <climits>

const unsigned int DefaultPreferedStringSize = 1 << 8; 

class String{
private:
    char *m_Array;
    size_t m_ReservedSize;
    size_t m_Size;
    
    void _grow(size_t newReservedSize) {
        if (m_ReservedSize ==0) {
            m_ReservedSize = DefaultPreferedStringSize;
            while(newReservedSize > m_ReservedSize) {
                m_ReservedSize <<= 1;// prochaine puissance de deux..
            }
            m_Array= (char *) malloc(m_ReservedSize);
            m_Array[0] = '\0';
            return;
        } else {
            while(newReservedSize > m_ReservedSize) {
                m_ReservedSize <<= 1;// prochaine puissance de deux..
            }
            char *temp = (char *) malloc(m_ReservedSize);
            memcpy(temp, m_Array, m_Size + 1);
            free(m_Array);
            m_Array = temp;
            return;
        };
    };
    
public:
    typedef char* iterator;
    typedef const char* const_iterator;
    
    String() : m_ReservedSize(0), m_Size(0) {
        _grow(m_ReservedSize);
    };
    
    String(const String &source) : m_Array(NULL), m_ReservedSize(0), m_Size(0) {
        assign(source);
    };
    
    String(const char * source) : m_Array(NULL), m_ReservedSize(0), m_Size(0) {
        assign(source);
    };
    
    String(const char *source, int length) : m_Array(NULL), m_ReservedSize(0), m_Size(0) {
        assign(source, length);
    };
    
    String(const_iterator first, const_iterator last) : m_Array(NULL), m_ReservedSize(0), m_Size(0) {
        assign(first, last);
    };
    
    String& operator = (const String &source) {
        return assign(source); 
    };
    
    String& operator = (const char * source) {
        return assign(source);
    };

    ~String() {
        free(m_Array);
    };
    
    String & assign(const char *source) {
        size_t length = strlen(source);
        if (length + 1> m_ReservedSize) {
            _grow(length + 1);
        }
        memcpy(m_Array, source, length + 1);
        m_Size = length;
        return *this;
    };

    String & assign(const char *source, size_t length) {
        if (length + 1> m_ReservedSize) {
            _grow(length + 1);
        }
        memcpy(m_Array, source, length + 1);
        m_Size = length;
        m_Array[length] = '\0';
        return *this;
    };

    String & assign(const_iterator first, const_iterator last) {
        size_t length = last - first;
        if (length<0) length = 0;
        if (length + 1 > m_ReservedSize) {
            _grow(length + 1);
        }
        memcpy(m_Array, first, length);
        m_Size = length;
        m_Array[length] = '\0';
        return *this;
    };

    String & assign(const String &source) {
        size_t length = source.size();
        if (length > m_ReservedSize) {
            _grow(length + 1);
        }        
        memcpy(m_Array, source.c_str(), length + 1);
        m_Size = length;
        return *this;
    };
    
    String & append(const char *source) {
        size_t length = strlen(source);
        if (m_Size + length + 1> m_ReservedSize) {
            _grow(m_Size + length + 1);
        }
        memcpy(m_Array + m_Size, source, length + 1);
        m_Size += length;
        return *this;
    };

    String & append(const char *source, int length) {
        if (m_Size +length + 1> m_ReservedSize) {
            _grow(m_Size +length + 1);
        }
        memcpy(m_Array + m_Size, source, length + 1);
        m_Size += length;
        m_Array[m_Size] = '\0';
        return *this;
    };

    String & append(const_iterator first, const_iterator last) {
        size_t length = last - first;
        if (length < 0) length = 0;
        if (m_Size + length + 1 > m_ReservedSize) {
            _grow(m_Size + length + 1);
        }
        memcpy(m_Array + m_Size, first, length);
        m_Size += length;
        m_Array[m_Size] = '\0';
        return *this;
    };

    String & append(const String &source) {
        size_t length = source.size();
        if (m_Size + length + 1> m_ReservedSize) {
            _grow(m_Size + length + 1);
        }        
        memcpy(m_Array + m_Size, source.c_str(), length + 1);
        m_Size += length;
        return *this;
    };

    String & append(char _c) {
        if (m_Size + 2> m_ReservedSize) {
            _grow(m_Size + 2);
        }
        m_Array[m_Size] = _c;
        m_Size++;
        m_Array[m_Size] = '\0';
        return *this;
    };

    String & append(int _i) {
        return append((long) _i);
    };
    
    String & append(unsigned int _i) {
        return append((unsigned long) _i);
    };

    String & append(long _i) {
        char buf[40]; // _itoa va stocker jusqu'a 33 octets donc c'est safe!!
        assert (LONG_MAX < 1e23);
        sprintf(buf, "%ld", _i);

        size_t length = strlen(buf);

        if (m_Size + length + 1> m_ReservedSize) {
            _grow(m_Size + length + 1);
        }
        memcpy(m_Array + m_Size, buf, length + 1);
        m_Size += length;
        return *this;
    };

    String & append(unsigned long _i) {
        char buf[40]; // _itoa va stocker jusqu'a 33 octets donc c'est safe!!
        assert (LONG_MAX < 1e23);
        sprintf(buf, "%lu", _i);

        size_t length = strlen(buf);

        if (m_Size + length + 1> m_ReservedSize) {
            _grow(m_Size + length + 1);
        }
        memcpy(m_Array + m_Size, buf, length + 1);
        m_Size += length;
        return *this;
    };

    const char * c_str() const{
        return m_Array;
    };

    size_t size() const{
        return m_Size;
    };

    bool empty() const{
        return (m_Size == 0);
    }
    
    int compare(const String &source) const {
        return strcmp(m_Array, source.c_str());
    }
    int compare(const char * source) const {
        return strcmp(m_Array, source);
    }

    void resize(size_t newSize) {
        if (newSize + 1 > m_ReservedSize) {
            _grow(newSize + 1);
        }        
        m_Size = newSize;
        m_Array[m_Size] = '\0';
    }

    iterator begin(){
        return m_Array;
    }

    iterator end() {
        return m_Array + m_Size;
    }

    String substr(int pos, int n) const{
        return String(m_Array + pos, m_Array + pos + n);
    };

    int find_last_of(char _c) const {
        int i = int(m_Size - 1);
        while (i >= 0) {
            if (_c == m_Array[i])
                return i;
            i--;
        }

        return -1; // non trouv�
    }
};

inline bool operator <(const String& _str1, const String& _str2) {
    return strcmp( _str1.c_str(), _str2.c_str()) < 0;
}

#endif //__CMSTRING_H
